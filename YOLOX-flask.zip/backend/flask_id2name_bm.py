id2name = {0: 'ball',
 1: 'messi'}
